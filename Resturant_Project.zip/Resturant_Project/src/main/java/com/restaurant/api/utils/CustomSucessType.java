package com.restaurant.api.utils;
public class CustomSucessType {
 
    private String Message;
 
    public CustomSucessType(String Message){
        this.Message = Message;
    }
 
    public String getMessage() {
        return Message;
    }
 
}